//DOM

const lampada = document.querySelector("#lampaApagada")
const ligar = document.querySelector("#one")
const desligar = document.querySelector("#two")


//EVENTO

ligar.addEventListener('click',acender)
desligar.addEventListener('click',apagar)
ligar.addEventListener('dblclick', quebrar); 

//FUNÇOES

function acender(){
    if (!isQuebrada()) {
    lampada.src='imagem/ligada.gif'
    }
}

function apagar(){
    if (!isQuebrada()) {
    lampada.src='imagem/apagada.gif'
    }
  
}

function quebrar(){
    lampada.src='imagem/quebrada (1).jpg'
    
}
 
function isQuebrada(){
    return lampada.src.includes('quebrada')
}